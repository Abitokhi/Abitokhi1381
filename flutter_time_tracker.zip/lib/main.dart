
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

void main() => runApp(const MyApp());

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'گزارش ساعت کاری',
      theme: ThemeData(
        fontFamily: 'Vazirmatn',
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.teal),
        useMaterial3: true,
      ),
      home: const TimeTablePage(),
    );
  }
}

class TimeTablePage extends StatefulWidget {
  const TimeTablePage({super.key});

  @override
  State<TimeTablePage> createState() => _TimeTablePageState();
}

class _TimeTablePageState extends State<TimeTablePage> {
  final List<Map<String, TimeOfDay?>> _rows = List.generate(10, (_) => {
        'ورود ۱': null,
        'خروج ۱': null,
        'ورود ۲': null,
        'خروج ۲': null,
        'ورود ۳': null,
        'خروج ۳': null,
      });

  final List<DateTime?> _dates = List.generate(10, (_) => null);

  Future<void> _pickTime(int row, String key) async {
    final TimeOfDay? picked = await showTimePicker(
      context: context,
      initialTime: TimeOfDay.now(),
      builder: (context, child) => Directionality(
        textDirection: TextDirection.rtl,
        child: child!,
      ),
    );
    if (picked != null) {
      setState(() {
        _rows[row][key] = picked;
      });
    }
  }

  Future<void> _pickDate(int row) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime(2020),
      lastDate: DateTime(2100),
      builder: (context, child) => Directionality(
        textDirection: TextDirection.rtl,
        child: child!,
      ),
    );
    if (picked != null) {
      setState(() {
        _dates[row] = picked;
      });
    }
  }

  Duration _calculateTotal(Map<String, TimeOfDay?> times) {
    Duration total = Duration.zero;
    for (var i = 1; i <= 3; i++) {
      final start = times['ورود $i'];
      final end = times['خروج $i'];
      if (start != null && end != null) {
        final startMinutes = start.hour * 60 + start.minute;
        final endMinutes = end.hour * 60 + end.minute;
        total += Duration(minutes: endMinutes - startMinutes);
      }
    }
    return total;
  }

  String _formatDuration(Duration duration) {
    final hours = duration.inHours;
    final minutes = duration.inMinutes % 60;
    return '$hours ساعت و $minutes دقیقه';
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('ثبت ساعات کاری'),
        ),
        body: SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          child: Column(
            children: [
              Row(
                children: const [
                  _TableHeader('تاریخ'),
                  _TableHeader('ورود ۱'),
                  _TableHeader('خروج ۱'),
                  _TableHeader('ورود ۲'),
                  _TableHeader('خروج ۲'),
                  _TableHeader('ورود ۳'),
                  _TableHeader('خروج ۳'),
                  _TableHeader('جمع'),
                ],
              ),
              ...List.generate(_rows.length, (index) {
                final row = _rows[index];
                final date = _dates[index];
                final total = _calculateTotal(row);
                return Row(
                  children: [
                    _TableCell(
                      label: date != null
                          ? DateFormat('yyyy/MM/dd').format(date)
                          : 'انتخاب تاریخ',
                      onTap: () => _pickDate(index),
                    ),
                    ...row.keys.map((key) => _TableCell(
                          label: row[key] != null
                              ? row[key]!.format(context)
                              : key,
                          onTap: () => _pickTime(index, key),
                        )),
                    _TableCell(
                      label: _formatDuration(total),
                      onTap: null,
                      isTotal: true,
                    ),
                  ],
                );
              }),
            ],
          ),
        ),
      ),
    );
  }
}

class _TableHeader extends StatelessWidget {
  final String title;
  const _TableHeader(this.title);

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 100,
      padding: const EdgeInsets.all(8),
      color: Colors.teal.shade700,
      child: Text(title,
          style: const TextStyle(fontWeight: FontWeight.bold, color: Colors.white),
          textAlign: TextAlign.center),
    );
  }
}

class _TableCell extends StatelessWidget {
  final String label;
  final VoidCallback? onTap;
  final bool isTotal;

  const _TableCell({required this.label, this.onTap, this.isTotal = false});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      child: Container(
        width: 100,
        padding: const EdgeInsets.all(8),
        margin: const EdgeInsets.all(1),
        decoration: BoxDecoration(
          color: isTotal ? Colors.grey.shade300 : Colors.grey.shade100,
          border: Border.all(color: Colors.grey.shade400),
        ),
        child: Text(
          label,
          textAlign: TextAlign.center,
        ),
      ),
    );
  }
}
